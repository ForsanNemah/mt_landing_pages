 


var phn="966540915499";
var msg="تم التسجيل بنجاح ";
var end_date="29-1-2023";
var end_time="12:00";
var action_url="https://script.google.com/macros/s/AKfycbzwANoHl4m_ynPclSXuICbUeTeSuXdttsyaLUKznT3VHIH6rsWFE01Ls3oSCmLrGbdu2Q/exec";







 